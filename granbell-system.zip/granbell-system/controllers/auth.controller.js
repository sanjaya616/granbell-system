const db = require('../db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const register = async (req, res) => {
  const { first_name, last_name, email, password, phone, country } = req.body;
  try {
    const existing = await db.query('SELECT 1 FROM guest WHERE email = $1', [email]);
    if (existing.rows.length) {
      return res.status(409).json({ error: 'Email already registered' });
    }
    const hashed = await bcrypt.hash(password, 12);
    const result = await db.query(
      `INSERT INTO guest (first_name, last_name, email, password_hash, phone, country)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING guest_id, first_name, last_name, email`,
      [first_name, last_name, email, hashed, phone, country]
    );
    const user = result.rows[0];
    const token = jwt.sign({ id: user.guest_id, role: 'GUEST' }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN,
    });
    res.status(201).json({ user, token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

const login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const result = await db.query(
      'SELECT guest_id, first_name, last_name, email, password_hash FROM guest WHERE email = $1 AND deleted_at IS NULL',
      [email]
    );
    if (!result.rows.length) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const user = result.rows[0];
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    const token = jwt.sign({ id: user.guest_id, role: 'GUEST' }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN,
    });
    res.json({ user: { guest_id: user.guest_id, first_name: user.first_name, last_name: user.last_name, email: user.email }, token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = { register, login };