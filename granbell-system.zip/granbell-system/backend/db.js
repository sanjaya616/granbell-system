const { Pool } = require("pg");
require("dotenv").config();

const pool = new Pool({
    user: "postgres",
    password: "Sana2000",
    host: "localhost",
    database: "granbell_db",
    port: 5432
});

module.exports = pool;