const db = require('../db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Helper to generate JWT
const generateToken = (id, role) => {
  return jwt.sign({ id, role }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN,
  });
};

// Register a new guest
const register = async (req, res) => {
  const { first_name, last_name, email, password, phone, country } = req.body;
  try {
    // Check if email exists
    const existing = await db.query('SELECT 1 FROM guest WHERE email = $1', [email]);
    if (existing.rows.length) {
      return res.status(409).json({ error: 'Email already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    const result = await db.query(
      `INSERT INTO guest (first_name, last_name, email, password_hash, phone, country)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING guest_id, first_name, last_name, email`,
      [first_name, last_name, email, hashedPassword, phone, country]
    );

    const user = result.rows[0];
    const token = generateToken(user.guest_id, 'GUEST');

    res.status(201).json({ user, token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Login guest
const login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const result = await db.query(
      'SELECT guest_id, first_name, last_name, email, password_hash FROM guest WHERE email = $1 AND deleted_at IS NULL',
      [email]
    );
    if (!result.rows.length) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const user = result.rows[0];
    const valid = await bcrypt.compare(password, user.password_hash);
    if (!valid) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = generateToken(user.guest_id, 'GUEST');
    res.json({
      user: {
        guest_id: user.guest_id,
        first_name: user.first_name,
        last_name: user.last_name,
        email: user.email,
      },
      token,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

module.exports = { register, login };