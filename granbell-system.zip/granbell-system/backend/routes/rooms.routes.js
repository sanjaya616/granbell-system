const router = require('express').Router();
const {
  getAllRooms,
  getAvailableRooms,
  getRoomById,
} = require('../controllers/rooms.controller');

router.get('/', getAllRooms);
router.get('/available', getAvailableRooms);
router.get('/:id', getRoomById);

module.exports = router;