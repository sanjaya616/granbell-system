const express = require('express');
const cors = require('cors');
require('dotenv').config();

const app = express();

// ----- Import routes (to be created later) -----
const authRoutes = require('./routes/auth.routes');
const roomsRoutes = require('./routes/rooms.routes');
const bookingsRoutes = require('./routes/bookings.routes');
const paymentsRoutes = require('./routes/payments.routes');
const adminRoutes = require('./routes/admin/admin.routes');

// ----- Middleware -----
// CORS – allow your React frontend
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true,
}));

// IMPORTANT: Stripe webhook needs raw body, so handle it BEFORE express.json()
app.use('/api/payments/webhook', express.raw({ type: 'application/json' }), paymentsRoutes);

// For all other routes, use JSON parsing
app.use(express.json());

// ----- Routes -----
app.use('/api/auth', authRoutes);
app.use('/api/rooms', roomsRoutes);
app.use('/api/bookings', bookingsRoutes);
app.use('/api/payments', paymentsRoutes); // this will not include the webhook sub‑route again
app.use('/api/admin', adminRoutes);

// Health check
app.get('/health', (req, res) => {
  res.json({ status: 'OK', hotel: 'Granbell Colombo' });
});

// ----- Global error handler -----
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
});

module.exports = app;