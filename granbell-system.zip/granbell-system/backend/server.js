const app = require('./app');          // import the configured Express app
const pool = require('./db');           // your database pool
const PORT = process.env.PORT || 5000;

// Optional: test database connection on startup
pool.query("SELECT NOW()", (err, res) => {
  if (err) {
    console.error("Database connection error:", err);
  } else {
    console.log("Database connected at:", res.rows[0]);
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});